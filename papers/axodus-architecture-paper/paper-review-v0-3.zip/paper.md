---
title: "Axodus: A Prototype-Stage Conceptual Architecture for Traceability and Accountability in Human-AI-Assisted Digital Institutions"
author:
  - "Mauricio Z. Filho"
affiliation: "Independent Researcher, Axodus"
correspondence: "mzfshark@gmail.com"
project_discussion_forum: "Telegram @thinkincoin"
author_social_handle: "@mzfshark"
version: "Draft v0.3"
status: "Internal author review required; not ready for publication"
license: "CC BY 4.0"
document_type: "Prototype-stage conceptual architecture and focused research-agenda paper"
---

# Abstract

Digital institutions increasingly rely on automated assistance while still
requiring identifiable authority, reviewable evidence, and accountable human
oversight. Existing literatures address socio-technical design, decentralized
governance, human–AI interaction, and credentialing standards, but they do not
by themselves yield a focused conceptual architecture for traceability and
accountability in human–AI-assisted institutional decision making. This paper
presents Axodus as a prototype-stage conceptual architecture and focused
research agenda for that problem. Its central contribution is a layered model
for linking decision authority, evidence, bounded AI assistance, rationale,
and review paths in digital institutions. Supporting discussion addresses
participation readiness, bounded risk constraints, and the distinction between
documentation maturity and development maturity. Axodus is described only as a
conceptual, prototype-stage model. The paper reports no deployed system,
empirical validation, operational readiness, or token-linked mechanism.

**Keywords:** socio-technical systems; digital institutions; human–AI
coordination; traceability; accountability; governance; contestability

# 1. Introduction

Digital institutions can combine distributed governance, public
documentation, automated assistance, and participation requirements within the
same decision environment. Those capabilities do not by themselves determine
who may decide, what evidence supports a decision, how an automated analysis
should be reviewed, or how an affected party can challenge an outcome.
Socio-technical systems research therefore treats organizational design and
technical design as interdependent rather than assuming that one can be
derived from the other [@baxter2011sociotechnical].

Relevant literatures clarify parts of this problem but do not yet yield a
single focused institutional model for traceability and accountability under
human–AI-assisted decision making. Research on decentralized governance
highlights the continuing importance of interpretation, change, and social
coordination around self-executing rules [@hassan2021dao; @hsieh2018bitcoin].
Human–AI interaction guidance emphasizes expectation setting, correction, and
review rather than an undifferentiated transfer of authority
[@amershi2019guidelines]. Credentialing standards help separate machine
verification from institutional judgment [@w3c2025vcdm]. What remains less
clearly specified is how authority, evidence, bounded AI assistance,
contestability, and review paths should be organized together in one
inspectable conceptual architecture.

This paper addresses that gap by introducing Axodus as a prototype-stage
conceptual architecture and focused research agenda. The project originates
from a multi-year independent research and design effort. The present
contribution is limited to a model: it does not report a functioning platform,
production deployment, users, evaluation results, validated controls, or any
token-linked participation mechanism.

The central contribution is a layered architecture for traceability and
accountability in human–AI-assisted digital institutions. It links
institutional authority, evidence, bounded AI assistance, decision rationale,
and review paths. Participation readiness, maturity separation, and risk
boundaries remain in the paper only as supporting components needed to frame
how such an architecture might be inspected and eventually evaluated.

Several matters are outside the paper's scope. The manuscript does not claim
an implemented system, validated governance outcomes, calibrated human-AI
reliance, demonstrated educational effects, security guarantees, or
operational readiness. It also does not address token minting, token supply,
value accrual, incentives, or other tokenomics questions, which require
separate legal, economic, and empirical review.

# 2. Background and Related Work

## 2.1 Socio-technical and digital institutions

A socio-technical perspective asks how roles, incentives, work practices,
information, and technology jointly shape outcomes. Baxter and Sommerville
argue for integrating organizational concerns with systems engineering rather
than treating them as a late adoption problem
[@baxter2011sociotechnical]. Axodus adopts this perspective by modeling
governance and accountability as architectural elements, not external policy
documents attached after implementation.

The term *digital institution* is used here for an organized system of roles,
rules, records, and technical capabilities through which participants pursue
collective activity. It does not require that every rule be executable or that
every interaction occur on a blockchain.

## 2.2 Decentralized governance, traceability, and review

Hassan and De Filippi describe a DAO as a blockchain-based system in which
people coordinate through decentralized governance and self-executing rules
[@hassan2021dao]. Hsieh et al. distinguish machine consensus from the social
consensus required to alter protocols and organizational arrangements
[@hsieh2018bitcoin]. These distinctions caution against equating technical
distribution with accountable governance.

Research on composable digital infrastructures also shows how dependencies can
propagate across connected components and governance arrangements
[@schar2021defi]. The relevance of this literature here is limited: it shows
that technical coordination can amplify the consequences of weak review paths,
unclear authority, and poor decision traceability.

## 2.3 Human–AI oversight, calibrated reliance, and governance

Guidelines for human–AI interaction emphasize communicating system
capabilities, supporting correction, and learning from behavior over time
[@amershi2019guidelines]. At the organizational level, the NIST AI Risk
Management Framework treats governance, mapping, measurement, and management
as connected risk functions [@tabassi2023airmf]. These sources motivate an
architecture in which AI outputs are attributable inputs to decisions rather
than sovereign decisions and in which human review conditions remain visible.

Constitutional AI uses written principles to guide model behavior through
supervised learning and AI feedback [@bai2022constitutional]. Axodus uses
*constitutional* differently: it refers to institutional rules about
authority, prohibitions, amendments, review, and appeal. The proposed model
does not claim to train or align an AI model through Constitutional AI.

## 2.4 Credentials, participation readiness, and institutional judgment

The W3C Verifiable Credentials Data Model separates the cryptographic
verification of a credential from validation of whether its claims are fit for
a verifier's purpose [@w3c2025vcdm]. This matters here because a technically
verifiable record would not by itself establish fair assessment, learning, or
legitimate governance restriction.

# 3. Problem Statement

The architecture addresses a design problem rather than an established
empirical effect:

> How can a digital institution make human–AI-assisted decisions more
> traceable, contestable, and accountable by linking authority, evidence,
> rationale, and review paths without conflating documentation with
> implementation or automation with legitimate governance?

Five tensions structure the problem.

1. **Modularity versus coherence.** Independent components can limit coupling,
   but shared decisions require common identity, evidence, and review rules.
2. **Participation versus readiness.** Open participation may support legitimacy,
   while consequential decisions may require demonstrated understanding.
3. **Automation versus accountability.** AI assistance can reduce analytical
   load, but responsibility can become unclear when its outputs influence
   action.
4. **Transparency versus privacy and security.** Traceable decisions need
   records, while indiscriminate disclosure can harm participants or expose
   systems.
5. **Documentation versus operational truth.** A detailed specification can
   improve review while creating a misleading impression of completion.

Axodus is proposed as one architecture for making these tensions explicit. It
is not presented as their solution.

# 4. Conceptual Architecture

The model comprises six logical layers. They describe responsibilities and
interfaces, not an implementation topology.

## 4.1 Constitutional governance

The governance layer states roles, decision rights, prohibitions, amendment
rules, escalation paths, and appeal mechanisms. Its purpose is to make higher-
order authority visible. A valid action would need both technical
authorization and institutional justification; neither alone would establish
legitimacy.

## 4.2 Evidence and accountability

The evidence layer links proposals, supporting material, declared conflicts,
AI-generated analyses, decisions, responsible roles, and subsequent reviews.
The design objective is reconstructability: a reviewer should be able to ask
what was known, who was authorized, what assistance was used, and why an
outcome followed. The proposal does not assume that more data automatically
produces accountability.

## 4.3 Modular institutional components

Bounded components represent institutional capabilities such as proposal
review, record keeping, or participation support. Each component should
declare its purpose, inputs, outputs, authority, dependencies, evidence
requirements, and failure behavior. In this paper, modularity matters chiefly
because it affects how responsibility, evidence, and failure can be traced
across decision processes. No definitive inventory or implementation status is
asserted in this draft.

## 4.4 Participation readiness support

An educational layer and a participation readiness mechanism are proposed as
supporting interfaces for learning and assessment. Their purpose would be to
help participants understand domain-specific risks and governance duties
before performing selected consequential actions. In this paper, they are
supporting elements rather than co-equal contributions. They must not become a
general social ranking system.

## 4.5 Human–AI assistance

AI services may support bounded tasks such as document comparison, proposal
summarization, inconsistency detection, risk flagging, and preparation of
review material. Each use should declare the task, source material, output,
uncertainty where available, human reviewer, and disposition. Humans retain
decision authority and responsibility.

## 4.6 Risk and review boundaries

The risk layer expresses constraints on authority, exposure, timing,
conflicts, and escalation. Its purpose is to make consequential decisions
reviewable in relation to defined boundaries rather than to imply a working
control system. In v0.3, this layer is included because it supports
accountability and reviewability, not because it is itself the paper's central
contribution. The paper claims no implemented enforcement, security property,
or live operational control.

# 5. Modularity and Maturity as Supporting Controls

Axodus proposes two distinct maturity axes. L0–L5 represents documentation
maturity; D0–D5 represents development maturity. In this paper, the
distinction matters only because it helps prevent documentation from being
mistaken for implemented or validated accountability mechanisms. This draft
does not define the individual levels, assign scores, or report component
status.

The separation is meant to avoid three category errors: treating a
specification as implemented behavior, treating a prototype as validated
institutional performance, and averaging unlike forms of maturity into one
reassuring score. If these axes remain in future work, they would require
explicit evidence criteria and independent review rather than self-assertion.

Modularity is likewise a supporting hypothesis rather than an assured
property. Component boundaries may aid review, but they can also move
complexity into interfaces and make governability harder to assess.

# 6. Participation Readiness as a Supporting Mechanism

**Terminology note.** Axodus notes use the internal label *Proof of Knowledge*
for the participation readiness mechanism discussed here. In this paper, the
mechanism is described in functional terms to avoid confusion with
cryptographic proof-of-knowledge protocols, proof-of-work, proof-of-stake, or
token-linked participation schemes.

At most, the mechanism would link defined learning objectives, assessment,
reviewable results, bounded eligibility, and an appeal path for selected
activities.

The W3C credential model could inform portable representations, but
verification of an issuer and credential does not validate educational quality
or justify authorization [@w3c2025vcdm]. The governance problem therefore
includes who defines the criteria, how accommodations are provided, and how a
participant can contest an outcome.

The central hypothesis is that a participation readiness mechanism may improve
the quality of participation in selected high-consequence contexts. A
secondary descriptive phrase for this idea is *knowledge-gated participation*.
Competing hypotheses remain equally important: the mechanism may exclude
participants, centralize curriculum power, encourage test gaming, or create
privacy risks. It should be rejected or redesigned if those harms cannot be
controlled.

# 7. Governance, Accountability, and Human Oversight

The proposed decision record has seven conceptual fields: decision scope,
authorized roles, evidence considered, conflicts disclosed, automated
assistance used, decision and rationale, and review or appeal path. This is a
minimum accountability model, not a database schema.

AI assistance is governed by task-specific boundaries. Low-consequence
drafting may permit lightweight review; risk classification or proposal
analysis would require stronger provenance, independent checking, and explicit
human disposition. An AI output cannot approve its own use, resolve an appeal
about itself, or become the final bearer of responsibility.

The model should support contestability. Participants affected by a decision
need a way to identify applicable rules, challenge evidence, correct records,
and request review by an appropriately independent role. Immutable records,
where used, must not be treated as immutable interpretations.

These requirements align with risk-oriented governance and human–AI
interaction guidance [@tabassi2023airmf; @amershi2019guidelines], but their
effectiveness in Axodus remains untested.

# 8. Risk Boundaries as Supporting Constraints

Risk boundaries are included here only as supporting constraints on action,
exposure, process, and escalation. Their role is to make consequential
decisions reviewable in context rather than to introduce a parallel governance
program. Visible records alone do not make assumptions or rationales
inspectable, and dependencies can still propagate across connected components
[@schar2021defi].

Questions about live asset policies, token-linked participation, supply
mechanisms, or financial incentives are outside the scope of this paper.
Before any such design were documented publicly, it would require separate
legal, economic, and empirical review in addition to threat modeling and
simulation.

# 9. Prototype Status

Axodus is presented in this paper as a conceptual, prototype-stage model. The
public repository presently supports editorial artifacts and research
documentation. It does not supply evidence of an integrated implementation,
production operation, user adoption, empirical performance, or effective
controls.

The absence of those claims is substantive. Architectural consistency can be
reviewed before implementation, but it cannot substitute for observed
behavior. Future versions should maintain a component-by-component evidence
table distinguishing designed, prototyped, tested, deployed, and independently
evaluated states.

# 10. Evaluation Plan

The evaluation program is intentionally prioritized rather than broad.

**Primary initial study — RQ1: Traceability.** Does the proposed evidence
model help independent reviewers reconstruct decisions more accurately and
efficiently than a document-only baseline? A study could use matched
governance scenarios, blinded reviewers, reconstruction accuracy, time,
disagreement, and missing-evidence detection. This is the paper's primary
evaluation priority because it most directly tests the central claim about
traceability and accountability.

**Secondary initial study — RQ3: Human–AI reliance.** For bounded
proposal-analysis tasks, how do provenance and mandatory human disposition
affect error detection, calibrated reliance, override behavior, and review
quality? Experiments should include planted AI errors and ambiguous cases.
This is a secondary priority because the architecture depends on bounded AI
assistance being reviewable rather than merely available.

**Future work studies.** Later phases may address educational participation,
maturity reliability, and risk governance after the core traceability
architecture is tested through document inspection and bounded human–AI review
studies.

# 11. Limitations and Threats to Validity

This paper is conceptual and still broader than a mature external article
would ideally be. The architecture can appear coherent because it has not yet
encountered implementation constraints, institutional conflict, or field
conditions that would test whether its proposed review paths are workable.

The public evidence base for Axodus is currently limited to design
documentation. There are no results with which to assess feasibility,
usability, governance legitimacy, security, calibrated reliance, contestable
appeals, or social impact. Human oversight can become nominal when reviewers
lack time, authority, or expertise. AI assistance may be unreliable,
difficult to calibrate, or difficult to audit under realistic workload and
time pressure. Weak contestability or poorly designed appeal paths could make
traceability visible without making accountability meaningful.

Participation readiness mechanisms present particular risks of exclusion,
surveillance, curriculum capture, and false confidence. Modularity can hide
systemic coupling. Explicit rules can formalize unjust arrangements rather
than correct them. The proposed architecture may also be too complex to govern
in practice without substantial scope reduction.

Web3-facing governance designs may also encounter regulatory uncertainty,
operational fragility, and jurisdiction-specific compliance burdens.

The paper does not provide legal, financial, security, or investment advice.
Its terminology may not map cleanly onto every jurisdiction or research
community.

# 12. Research Agenda

Near-term work should prioritize a minimal decision-and-evidence model and
bounded AI-assistance tasks suitable for initial traceability studies.
Participation-readiness design, maturity specification, and broader governance
scenarios belong to later papers or technical notes, alongside educational
validity questions and any token-linked or financial design issues.

# 13. Conclusion

Axodus is proposed as a conceptual architecture for making human–AI-assisted
institutional decisions more traceable and accountable through linked
authority, evidence, rationale, and review paths. Its immediate value is not
demonstrated performance but inspectability: the model exposes claims,
interfaces, and accountability assumptions before operational maturity is
asserted.

The architecture will become a credible contribution only if its constructs
are specified, independently criticized, implemented in bounded prototypes,
and evaluated against alternatives. This draft establishes a research agenda
for that process. It is ready for human review, not for public publication.

# References

References are maintained in `references.bib`. All entries cited in this draft
have corresponding verification records in
`../../research/bibliography-verified.md`.
